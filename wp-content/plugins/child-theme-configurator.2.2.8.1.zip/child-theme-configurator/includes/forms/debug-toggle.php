<?php
// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;
?>
  <label for="ctc_is_debug" style="font-size:9px;float:right">
    <input class="ctc_checkbox" id="ctc_is_debug" name="ctc_is_debug"  type="checkbox" 
            value="1" <?php echo checked( $this->ctc()->is_debug, 1 ); ?> autocomplete="off" />
    <?php _e( 'Debug', 'child-theme-configurator' ); ?>
  </label>
